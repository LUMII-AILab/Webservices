while test 1=1
do
java -mx1g -cp dist/webservices.jar:dist/morphology.jar:lib/org.restlet.jar:dist/transliterator.jar:lib/json_simple-1.1.jar:lib/org.restlet.ext.json.jar:lib/org.json.jar:lib/mysql-connector-java-5.1.19-bin.jar lv.semti.morphology.webservice.MorphoServer
done

