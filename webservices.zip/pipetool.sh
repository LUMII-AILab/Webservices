#!/bin/bash

cd $(dirname $0)
java -Xmx2G -cp dist/webservices.jar:dist/morphology.jar:dist/transliterator.jar:lib/json_simple-1.1.jar:lib/commons-lang3-3.1.jar lv.semti.morphology.pipetool.WordPipe $*
